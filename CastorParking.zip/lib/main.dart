import 'package:flutter/material.dart';
import './widgets/MyApp.dart';

void main() => runApp(MyApp());
